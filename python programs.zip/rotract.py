n=input("enter a name")
a=int(input("enter a age "))
w=int(input("enter a weight"))
if(a>18 and w>40):
    print("1")
else:
    print("0")
    

