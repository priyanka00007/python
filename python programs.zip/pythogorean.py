a=int(input("enter a number"))
b=int(input("enter a number"))
c=int(input("enter a number"))
if(a*a+b*b==c*c):
    print(1)
else:
    print(0)
