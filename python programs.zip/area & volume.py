r=int(input("enter a radius of cylinder"))
h=int(input("enter a height of cylinder"))
pi=3.14
v=pi*((r*r)*h)
s=((2*pi*r)*h)+((pi*r**2)*2)
print("volume is",v)
print("surface area of cylinder is",s)

