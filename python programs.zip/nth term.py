a =int(input("enter the number: "))
b =int(input("enter the power: "))
c= a**b
if (c%2==0):
    print("nth power of the number is even")
else:
    print("nth power of the number is odd")