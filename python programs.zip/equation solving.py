x=int(input("enter a number"))
y=int(input("enter a number"))
if(x<y):
   z=(y-x)*(x+y)
else:
   z=(x-y)*(x+y)
   print(z)
