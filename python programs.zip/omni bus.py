a=int(input("enter a number"))
if(a>60):
    fare=1020*(20/100)
    print("discount amount",fare)
else:
    print("not eligibile")
