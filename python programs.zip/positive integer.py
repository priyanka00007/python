a=int(input("enter a number"))
if(a>0):
    print("positive integer")
elif(a<0):
    print("negative integer")
else:
    print("0")
    
